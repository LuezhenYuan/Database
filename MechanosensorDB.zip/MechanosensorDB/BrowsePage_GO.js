//This JS file contain Browse page GO of MechanosensorDB
//Use AJAX to send things to php
