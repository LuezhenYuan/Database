//This JS file contain Browse page Protein Name of MechanosensorDB
//Use AJAX to send things to php
function Show_BrowsePage(i){//Show check Which to browse
	var maincontent=document.getElementById("maincontent");
	maincontent.innerHTML="";//Delete all corrent DOM nodes
	var tmp_content="<h1 id='h11'></h1>";
}
