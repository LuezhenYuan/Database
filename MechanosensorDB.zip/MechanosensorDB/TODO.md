# Things to do
1. Search Page: search uniprot_ID

2. Browse uniprotID + organism

3. Back and Forward

1. KEGG and other Pathway DB, link first, then other
2. BioGrid local search
3. Pubmed local search
4. Organism specific DB
